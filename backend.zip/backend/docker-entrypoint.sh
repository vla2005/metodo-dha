#!/bin/sh
set -eu

echo "Aplicando migrations do banco..."
npx prisma migrate deploy --schema prisma/schema.prisma

echo "Iniciando a API do Método DHA..."
exec node dist/main.js

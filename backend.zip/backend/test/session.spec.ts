import { createOpaqueToken, hashToken } from '../src/common/session';
describe('sessão pública opaca', () => {
  it('gera tokens de alta entropia distintos', () => { const first = createOpaqueToken(); const second = createOpaqueToken(); expect(first).not.toBe(second); expect(first.length).toBeGreaterThanOrEqual(40); });
  it('persiste somente um hash determinístico', () => { const token = createOpaqueToken(); const hash = hashToken(token); expect(hash).toHaveLength(64); expect(hash).not.toContain(token); expect(hashToken(token)).toBe(hash); });
});

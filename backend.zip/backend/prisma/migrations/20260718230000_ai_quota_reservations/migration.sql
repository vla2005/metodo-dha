BEGIN;

CREATE TYPE "AiQuotaReservationStatus" AS ENUM ('RESERVED', 'SENT', 'FAILED');

CREATE TABLE "AiQuotaReservation" (
  "id" UUID NOT NULL,
  "quotaId" UUID NOT NULL,
  "operationId" UUID,
  "attemptStartedAt" TIMESTAMP(3) NOT NULL,
  "status" "AiQuotaReservationStatus" NOT NULL DEFAULT 'RESERVED',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "finalizedAt" TIMESTAMP(3),

  CONSTRAINT "AiQuotaReservation_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "AiQuotaReservation_finalization_check" CHECK (
    ("status" = 'RESERVED' AND "finalizedAt" IS NULL)
    OR ("status" <> 'RESERVED' AND "finalizedAt" IS NOT NULL)
  )
);

CREATE UNIQUE INDEX "AiQuotaReservation_operationId_attemptStartedAt_key"
  ON "AiQuotaReservation"("operationId", "attemptStartedAt");
CREATE INDEX "AiQuotaReservation_quotaId_status_idx"
  ON "AiQuotaReservation"("quotaId", "status");

ALTER TABLE "AiQuotaReservation"
  ADD CONSTRAINT "AiQuotaReservation_quotaId_fkey"
    FOREIGN KEY ("quotaId") REFERENCES "AiDailyQuota"("id")
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT "AiQuotaReservation_operationId_fkey"
    FOREIGN KEY ("operationId") REFERENCES "AiOperation"("id")
    ON DELETE SET NULL ON UPDATE CASCADE;

COMMIT;

ALTER TABLE "WordCard"
ADD COLUMN "version" VARCHAR(32) NOT NULL DEFAULT 'dha-2026-v1';

ALTER TABLE "ImageCard"
ADD COLUMN "mimeType" VARCHAR(80) NOT NULL DEFAULT 'image/webp',
ADD COLUMN "contentHash" VARCHAR(64),
ADD COLUMN "version" VARCHAR(32) NOT NULL DEFAULT 'dha-2026-v1',
ADD COLUMN "descriptionReviewedAt" TIMESTAMP(3);

-- Registros fictícios preexistentes recebem um hash técnico temporário para a
-- migration poder ser aplicada. O seed oficial os desativa e preenche os hashes reais.
UPDATE "ImageCard"
SET "contentHash" = md5("storageKey") || md5('dha:' || "storageKey")
WHERE "contentHash" IS NULL;

ALTER TABLE "ImageCard"
ALTER COLUMN "contentHash" SET NOT NULL;

CREATE INDEX "ImageCard_contentHash_idx" ON "ImageCard"("contentHash");

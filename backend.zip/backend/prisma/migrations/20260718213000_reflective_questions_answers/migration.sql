-- A jornada permanece em CARTAS_CONCLUIDAS enquanto a operação de IA está
-- pendente, em processamento ou falhou. O estado muda somente depois que as
-- perguntas validadas forem persistidas de forma atômica.
ALTER TYPE "JourneyStatus" ADD VALUE IF NOT EXISTS 'PERGUNTAS_DISPONIVEIS';
ALTER TYPE "JourneyStatus" ADD VALUE IF NOT EXISTS 'RESPOSTAS_CONCLUIDAS';

CREATE TYPE "ReflectiveQuestionType" AS ENUM ('STEP', 'INTEGRATIVE');
CREATE TYPE "ReflectiveResponseType" AS ENUM (
  'TEXT',
  'NO_RELATION',
  'DONT_KNOW',
  'PREFER_NOT_TO_ANSWER',
  'SKIPPED'
);

-- Os defaults temporários preservam operações criadas antes desta migration.
-- updatedAt mantém DEFAULT NOW para permitir a detecção de PROCESSING abandonado
-- mesmo quando uma atualização operacional não passar pelo Prisma Client.
ALTER TABLE "AiOperation"
  ADD COLUMN "provider" VARCHAR(40) NOT NULL DEFAULT 'gemini',
  ADD COLUMN "schemaVersion" VARCHAR(32) NOT NULL DEFAULT 'v1',
  ADD COLUMN "thoughtTokens" INTEGER,
  ADD COLUMN "providerRequestId" VARCHAR(160),
  ADD COLUMN "startedAt" TIMESTAMP(3),
  ADD COLUMN "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

ALTER TABLE "AiOperation"
  ALTER COLUMN "provider" DROP DEFAULT,
  ALTER COLUMN "schemaVersion" DROP DEFAULT;

ALTER TABLE "AiOperation"
  ADD CONSTRAINT "AiOperation_provider_not_blank_check"
    CHECK (length(btrim("provider")) > 0),
  ADD CONSTRAINT "AiOperation_schema_version_not_blank_check"
    CHECK (length(btrim("schemaVersion")) > 0),
  ADD CONSTRAINT "AiOperation_thought_tokens_check"
    CHECK ("thoughtTokens" IS NULL OR "thoughtTokens" >= 0);

-- Índices compostos redundantes em relação às PKs permitem que as FKs abaixo
-- garantam no próprio banco que set, operação, pergunta e resposta pertencem à
-- mesma jornada.
CREATE UNIQUE INDEX "JourneySet_journeyId_id_position_key"
  ON "JourneySet"("journeyId", "id", "position");
CREATE UNIQUE INDEX "AiOperation_journeyId_id_key"
  ON "AiOperation"("journeyId", "id");

CREATE TABLE "ReflectiveQuestion" (
  "id" UUID NOT NULL,
  "journeyId" UUID NOT NULL,
  "journeySetId" UUID,
  "aiOperationId" UUID NOT NULL,
  "type" "ReflectiveQuestionType" NOT NULL,
  "stepNumber" INTEGER,
  "displayOrder" INTEGER NOT NULL,
  "text" VARCHAR(500) NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,

  CONSTRAINT "ReflectiveQuestion_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ReflectiveQuestion_display_order_check"
    CHECK ("displayOrder" > 0),
  CONSTRAINT "ReflectiveQuestion_text_not_blank_check"
    CHECK (length(btrim("text")) > 0),
  CONSTRAINT "ReflectiveQuestion_type_scope_check"
    CHECK (
      (
        "type" = 'STEP'
        AND "journeySetId" IS NOT NULL
        AND "stepNumber" BETWEEN 1 AND 5
      )
      OR
      (
        "type" = 'INTEGRATIVE'
        AND "journeySetId" IS NULL
        AND "stepNumber" IS NULL
      )
    )
);

CREATE UNIQUE INDEX "ReflectiveQuestion_id_journeyId_key"
  ON "ReflectiveQuestion"("id", "journeyId");
CREATE UNIQUE INDEX "ReflectiveQuestion_journeyId_displayOrder_key"
  ON "ReflectiveQuestion"("journeyId", "displayOrder");
CREATE INDEX "ReflectiveQuestion_journeySetId_idx"
  ON "ReflectiveQuestion"("journeySetId");
CREATE INDEX "ReflectiveQuestion_aiOperationId_idx"
  ON "ReflectiveQuestion"("aiOperationId");

CREATE TABLE "ReflectiveAnswer" (
  "id" UUID NOT NULL,
  "journeyId" UUID NOT NULL,
  "questionId" UUID NOT NULL,
  "responseType" "ReflectiveResponseType" NOT NULL,
  "text" VARCHAR(5000),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,

  CONSTRAINT "ReflectiveAnswer_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "ReflectiveAnswer_text_response_check"
    CHECK (
      (
        "responseType" = 'TEXT'
        AND "text" IS NOT NULL
        AND length(btrim("text")) > 0
      )
      OR
      (
        "responseType" <> 'TEXT'
        AND "text" IS NULL
      )
    )
);

CREATE UNIQUE INDEX "ReflectiveAnswer_questionId_key"
  ON "ReflectiveAnswer"("questionId");
CREATE UNIQUE INDEX "ReflectiveAnswer_questionId_journeyId_key"
  ON "ReflectiveAnswer"("questionId", "journeyId");
CREATE INDEX "ReflectiveAnswer_journeyId_idx"
  ON "ReflectiveAnswer"("journeyId");

ALTER TABLE "ReflectiveQuestion"
  ADD CONSTRAINT "ReflectiveQuestion_journeyId_fkey"
    FOREIGN KEY ("journeyId") REFERENCES "Journey"("id")
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT "ReflectiveQuestion_journeyId_journeySetId_stepNumber_fkey"
    FOREIGN KEY ("journeyId", "journeySetId", "stepNumber")
    REFERENCES "JourneySet"("journeyId", "id", "position")
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT "ReflectiveQuestion_journeyId_aiOperationId_fkey"
    FOREIGN KEY ("journeyId", "aiOperationId")
    REFERENCES "AiOperation"("journeyId", "id")
    ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "ReflectiveAnswer"
  ADD CONSTRAINT "ReflectiveAnswer_journeyId_fkey"
    FOREIGN KEY ("journeyId") REFERENCES "Journey"("id")
    ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT "ReflectiveAnswer_questionId_journeyId_fkey"
    FOREIGN KEY ("questionId", "journeyId")
    REFERENCES "ReflectiveQuestion"("id", "journeyId")
    ON DELETE CASCADE ON UPDATE CASCADE;

-- Há uma única geração canônica de perguntas por jornada. Requisições
-- repetidas reutilizam AiOperation/resultJson e as perguntas já persistidas.
CREATE UNIQUE INDEX "AiOperation_one_questions_per_journey_key"
  ON "AiOperation"("journeyId")
  WHERE "type" = 'QUESTIONS';
